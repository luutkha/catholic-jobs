export type BaseProps<T> = (any :any) => Promise<{ props: T }>
