import React from 'react'
import BlogEditor from '../../../components/layouts/text-editor/BlogEditor'

type Props = {}

const index = (props: Props) => {
    return (
        <div>
            <BlogEditor />
        </div>
    )
}

export default index