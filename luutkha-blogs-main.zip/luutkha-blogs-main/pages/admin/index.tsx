
const AdminPage = () => {
    return (
        <div>
            This site just for admin, please go out if you not one of them
        </div>
    )
}

export default AdminPage