export type BlogCardProps =  {
    title: string;
    type: string;
    imageUrl?: string;
    description?:string;

}